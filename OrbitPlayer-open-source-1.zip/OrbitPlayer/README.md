# Orbit Player

**Open-source Android music & video player** with a native dark UI, a local media library, playlists, favorites, and network-stream support.

![Android](https://img.shields.io/badge/Android-6.0%2B-3DDC84?logo=android&logoColor=white) ![Language](https://img.shields.io/badge/Java-17-blue) ![License](https://img.shields.io/badge/License-Apache--2.0-blue) ![Media3](https://img.shields.io/badge/Media3-1.11.1-0066cc)

> **Project status: pre-release source implementation, not yet verified on-device.** The build workflow is included, but a successful APK build and real-device playback test must happen before this is considered production ready. This is an original app inspired by the *category* of powerful mobile media players, not a clone of MX Player Pro or VLC.

## What is implemented

| Area | Available in source |
|---|---|
| Local video library | Read via Android MediaStore with modern scoped permissions |
| Local music library | Scan, search, artist/title metadata, duration |
| File picker | Open media directly via Android Storage Access Framework |
| Audio player | Play/pause, next/previous, seek, +/- 10 seconds, 0.5×–2× speed |
| Video player | Media3 PlayerView, position scrubbing, skip, speed, fit/fill/zoom, rotate |
| Network playback | HTTP(S) progressive, HLS, MPEG-DASH, and RTSP via Media3 extension modules |
| Streams | Paste an address, choose auto/HLS/DASH/direct, save/remove streams |
| Subtitle files | External SRT/VTT/ASS/SSA selection and built-in subtitle track button |
| Background music | MediaSessionService notification/system media controls, audio focus, headset unplug handling |
| Video PiP | Android 8.0+ picture-in-picture (device permitting) |
| Library organization | Favorites, create/delete playlists, add items to playlists |
| Play queue | Play album/list, extend via adding next, shuffle, repeat one/all/off |
| Open files from another app | Handles `ACTION_VIEW` for file/content/HTTP(S)/RTSP media |
| Accessibility | Descriptive item menu names and standard Android widgets |
| Privacy | No accounts, analytics, telemetry, external API keys, or advertisements |

**Important limits:** Files must use a codec/container supported by Android/Media3 on your device. Advanced VLC software codecs, DVD/ISO playback, SMB/FTP browsing, Chromecast, cloud-library sync, advanced equalizer, download manager, multi-audio-track guarantee, and DRM-enabled streaming are **not implemented**. Some ASS/SSA styling or codecs may be device-dependent. Incomplete/unsupported streams can fail gracefully.

## Requirements

- Android phone or tablet running **Android 6.0 (API 23)** or newer (minimum configured; actual playback depends on hardware and OS codecs).
- To build: Android Studio with Android SDK **API 36**, JDK **17**, Android Gradle Plugin **8.11.1**, Gradle **8.13**.
- Internet only to download dependencies *during build*, and to play an online network stream.

## Get an installable APK from GitHub (no Android Studio needed)

1. Upload this project to a new GitHub repository. Keep `.github/workflows/build-apk.yml` at its exact path.
2. Go to **Actions** → **Build Android APK** → **Run workflow**, or push a commit to `main`.
3. When the `android` job succeeds, open its run and download **OrbitPlayer-debug-apk** from the **Artifacts** section.
4. Extract the downloaded ZIP. The app itself is `app-debug.apk`.
5. Transfer `app-debug.apk` to your Android phone, open the file, and follow Android's installation prompts. The system may ask you to allow installs from the specific file-manager/browser app you're using.

**Debug APK signing:** Each clean GitHub Actions runner can use a different Android debug signing key. You may need to uninstall a previously installed debug APK before installing a later one. Uninstalling removes local app data such as favorites and playlists. For upgradable releases, configure a stable signing key as encrypted GitHub Actions secrets; never publish that private key.

### Build locally

```bash
# Install Android SDK API 36 and Android SDK build tools.
# Install Gradle 8.13 and JDK 17, or open this folder as a project in Android Studio.
gradle --no-daemon :app:assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

The project intentionally does **not** include the Gradle wrapper JAR because the project archive was generated in a tool environment without the Android build toolchain. Android Studio's Gradle configuration or the provided Actions workflow uses Gradle 8.13.

## User guide

### Local audio and video

1. Launch **Orbit Player**, grant audio/video library permissions.
2. Switch between **Videos** and **Music**; tap the magnifying-glass search field to filter.
3. Tap a media card to start playback. The three-dot menu adds a favorite, adds to a playlist, or inserts the track into the queue.
4. Use **+ OPEN** to select a file independently of the media scanner.

### Network streaming

1. Open the **Streams** tab, tap **+ ADD STREAM**.
2. Enter a trusted `https://`, `http://`, or `rtsp://` media URL, optionally name it.
3. If the server URL has no obvious extension, select **HLS / M3U8** or **MPEG-DASH / MPD** manually.
4. Tap **Save and play**. The stream stays locally in your saved list.

Plain HTML web pages (including regular video-sharing website URLs) **are not direct media stream URLs**. DRM and login-protected streams may require functionality that is not included.

### Subtitles and picture-in-picture

- In **Video Player**, use **SUBTITLES** to choose an SRT/VTT/ASS/SSA file. Media3 also provides an embedded track selector when tracks are available.
- Use **ASPECT** to switch fit/stretch/zoom, **ROTATE** for landscape, **SPEED** for 0.5–2×, or **PIP** on Android 8+.
- Network video requires the appropriate connection; mobile data charges may apply.

### Permissions and privacy

- `READ_MEDIA_AUDIO` and `READ_MEDIA_VIDEO` (Android 13+) or `READ_EXTERNAL_STORAGE` (Android 12 or older): to list on-device files.
- `INTERNET`/`ACCESS_NETWORK_STATE`: for playback of the direct URL you enter.
- `FOREGROUND_SERVICE`/`FOREGROUND_SERVICE_MEDIA_PLAYBACK` and `WAKE_LOCK`: keep music playback running in the background.
- `POST_NOTIFICATIONS` is declared for compatible notifications, but not actively requested in this version; playback notifications may depend on your Android notification settings.
- No sensitive usage events are uploaded. Local favorites, playlists, and stream addresses are saved **unencrypted** in app-private preferences. Do not store private access tokens in stream URLs.
- Cleartext HTTP is permitted for compatibility with home media servers. Prefer HTTPS whenever possible.

## Code layout

```text
app/src/main/java/com/orbit/player/
  MainActivity.java    Local library, tabs, search, streams, playlist management
  MusicActivity.java   Audio transport, seekbar, speed, queue
  VideoActivity.java   PlayerView, subtitles, PiP, speed and aspect controls
  PlaybackService.java Media3 background playback media session
  LibraryScanner.java  Android MediaStore scanner
  MediaEntry.java      Track/stream model, MIME type hints
  OrbitStore.java      Local favorites, streams and playlists
  Ui.java              Reusable native dark view components
.github/workflows/build-apk.yml   Build and upload an APK artifact
```

## Open source and attribution

Orbit Player's app code is licensed under **Apache License 2.0** (see [`LICENSE`](LICENSE)). It links to **AndroidX Media3 / ExoPlayer**, provided by Google under its own Apache-2.0 license. Dependencies are downloaded unmodified from Google's Maven repository and Maven Central. No MX Player, MX Player Pro, or VideoLAN/VLC source, code, branding, icons or other proprietary assets are included. Product names belong to their respective owners.

Contributions: see [`CONTRIBUTING.md`](CONTRIBUTING.md). Security: see [`SECURITY.md`](SECURITY.md). Roadmap: see [`ROADMAP.md`](ROADMAP.md).
