## Problem or feature

Please describe what you expected to happen and what actually happened.

## Reproduction

1. 
2. 
3. 

## Device information

- Android version:
- Phone model:
- Media format/stream protocol (do not include private URLs):

## Logs

Include sanitized logs only. Remove secrets, tokens, and private file paths.
