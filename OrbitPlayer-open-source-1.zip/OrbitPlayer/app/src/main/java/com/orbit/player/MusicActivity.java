package com.orbit.player;

import android.app.Activity;
import android.content.ComponentName;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import androidx.media3.common.C;
import androidx.media3.common.Player;
import androidx.media3.common.MediaItem;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Locale;

/** Full music transport, queue and playback speed controls. */
public final class MusicActivity extends Activity {
    private MediaController player;
    private ListenableFuture<MediaController> future;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView songTitle, songArtist, play, favorite, shuffle, repeat, position, duration;
    private SeekBar seekBar;
    private LinearLayout queueHost;
    private boolean scrubbing;
    private final Runnable tick=new Runnable(){
        @Override public void run(){refreshProgress();handler.postDelayed(this,600);}
    };
    private final Player.Listener listener=new Player.Listener(){
        @Override public void onEvents(Player p,Player.Events events){refreshAll();}
        @Override public void onPlayerError(androidx.media3.common.PlaybackException e){
            Toast.makeText(MusicActivity.this,"Can't play: "+e.getErrorCodeName(),Toast.LENGTH_LONG).show();
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        render();
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        future=new MediaController.Builder(this,token).buildAsync();
        future.addListener(()->{
            try {if(isFinishing()||isDestroyed())return;player=future.get();player.addListener(listener);refreshAll();}
            catch(Exception e){Toast.makeText(this,"Music player unavailable",Toast.LENGTH_LONG).show();}
        },command->handler.post(command));
        handler.post(tick);
    }
    private void render(){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout main=Ui.vertical(this);
        main.setPadding(Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,28));
        scroll.addView(main);
        setContentView(scroll);
        LinearLayout bar=Ui.horizontal(this);
        TextView back=Ui.button(this,"←",false);back.setOnClickListener(v->finish());bar.addView(back);
        TextView label=Ui.text(this,"  NOW PLAYING",13,Ui.MUTED,true);
        label.setLetterSpacing(.16f);bar.addView(label,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
        TextView speed=Ui.button(this,"SPEED",false);
        speed.setOnClickListener(v->showSpeed());bar.addView(speed);
        main.addView(bar);

        TextView artwork=Ui.text(this,"♫",100,Ui.BLUE,true);
        artwork.setGravity(Gravity.CENTER);
        artwork.setBackground(Ui.bg(this,Ui.PANEL,28));
        LinearLayout.LayoutParams artParams=Ui.lp(this,-1,260,0,24,0,27);
        main.addView(artwork,artParams);
        songTitle=Ui.text(this,"Nothing playing",26,Ui.WHITE,true);
        songTitle.setGravity(Gravity.CENTER);
        songTitle.setMaxLines(2);
        main.addView(songTitle,Ui.lp(this,-1,65,0,0,0,0));
        songArtist=Ui.text(this,"Orbit Player",13,Ui.MUTED,false);
        songArtist.setGravity(Gravity.CENTER);
        main.addView(songArtist,Ui.lp(this,-1,34,0,0,0,12));

        LinearLayout extra=Ui.horizontal(this);
        shuffle=Ui.button(this,"SHUFFLE",false);shuffle.setOnClickListener(v->{if(player!=null){player.setShuffleModeEnabled(!player.getShuffleModeEnabled());refreshAll();}});
        extra.addView(shuffle);
        extra.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
        favorite=Ui.button(this,"♡ FAVORITE",false);
        favorite.setOnClickListener(v->{
            if(player!=null&&player.getCurrentMediaItem()!=null){new OrbitStore(this).toggleFavorite(player.getCurrentMediaItem().mediaId);refreshAll();}
        });
        extra.addView(favorite);
        extra.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
        repeat=Ui.button(this,"REPEAT",false);
        repeat.setOnClickListener(v->{
            if(player==null)return;
            int current=player.getRepeatMode();
            player.setRepeatMode(current==Player.REPEAT_MODE_OFF?Player.REPEAT_MODE_ALL:
                current==Player.REPEAT_MODE_ALL?Player.REPEAT_MODE_ONE:Player.REPEAT_MODE_OFF);
            refreshAll();
        });
        extra.addView(repeat);
        main.addView(extra,Ui.lp(this,-1,55,0,0,0,8));
        seekBar=new SeekBar(this);
        seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.BLUE));
        seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(Ui.BLUE));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int p,boolean user){if(user&&player!=null)position.setText(Ui.time(p));}
            @Override public void onStartTrackingTouch(SeekBar b){scrubbing=true;}
            @Override public void onStopTrackingTouch(SeekBar b){if(player!=null)player.seekTo(b.getProgress());scrubbing=false;}
        });
        main.addView(seekBar,Ui.lp(this,-1,38,0,8,0,0));
        LinearLayout timeline=Ui.horizontal(this);
        position=Ui.text(this,"0:00",12,Ui.MUTED,false);
        duration=Ui.text(this,"--:--",12,Ui.MUTED,false);
        timeline.addView(position,new LinearLayout.LayoutParams(0,Ui.dp(this,24),1));
        timeline.addView(duration);
        main.addView(timeline);
        LinearLayout transport=Ui.horizontal(this);
        transport.setGravity(Gravity.CENTER);
        TextView rewind=Ui.button(this,"↶ 10s",false);
        rewind.setOnClickListener(v->{if(player!=null)player.seekBack();});
        transport.addView(rewind,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1f));
        TextView prev=Ui.button(this,"|◀",false);
        prev.setOnClickListener(v->{if(player!=null)player.seekToPrevious();});
        transport.addView(prev,new LinearLayout.LayoutParams(0,Ui.dp(this,56),1f));
        play=Ui.button(this,"▶",true);play.setTextSize(25);
        play.setOnClickListener(v->{if(player!=null){if(player.isPlaying())player.pause();else player.play();}});
        transport.addView(play,new LinearLayout.LayoutParams(0,Ui.dp(this,70),1.25f));
        TextView next=Ui.button(this,"▶|",false);
        next.setOnClickListener(v->{if(player!=null)player.seekToNext();});
        transport.addView(next,new LinearLayout.LayoutParams(0,Ui.dp(this,56),1f));
        TextView forward=Ui.button(this,"10s ↷",false);
        forward.setOnClickListener(v->{if(player!=null)player.seekForward();});
        transport.addView(forward,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1f));
        main.addView(transport,Ui.lp(this,-1,84,0,11,0,11));
        TextView queueHeader=Ui.text(this,"UP NEXT  /  PLAY QUEUE",12,Ui.BLUE,true);
        queueHeader.setLetterSpacing(.15f);
        main.addView(queueHeader,Ui.lp(this,-1,45,0,8,0,0));
        queueHost=Ui.vertical(this);
        main.addView(queueHost);
    }
    private void refreshAll(){
        if(player==null||songTitle==null)return;
        MediaItem item=player.getCurrentMediaItem();
        songTitle.setText(item!=null&&item.mediaMetadata.title!=null?item.mediaMetadata.title:"Nothing playing");
        songArtist.setText(item!=null&&item.mediaMetadata.artist!=null?item.mediaMetadata.artist:"Audio");
        play.setText(player.isPlaying()?"Ⅱ":"▶");
        shuffle.setText(player.getShuffleModeEnabled()?"SHUFFLE ON":"SHUFFLE");
        repeat.setText(player.getRepeatMode()==Player.REPEAT_MODE_ONE?"REPEAT 1":
                player.getRepeatMode()==Player.REPEAT_MODE_ALL?"REPEAT ALL":"REPEAT");
        favorite.setText(item!=null && new OrbitStore(this).favorites().contains(item.mediaId)?"♥ FAVORITE":"♡ FAVORITE");
        refreshProgress();
        queueHost.removeAllViews();
        int count=Math.min(player.getMediaItemCount(),250);
        for(int i=0;i<count;i++){
            final int pos=i;
            MediaItem in=player.getMediaItemAt(i);
            String title=in.mediaMetadata.title==null?"Track "+(i+1):in.mediaMetadata.title.toString();
            TextView row=Ui.text(this,(i==player.getCurrentMediaItemIndex()?"▶  ":"♫  ")+title,
                    13,i==player.getCurrentMediaItemIndex()?Ui.BLUE:Ui.WHITE,false);
            row.setPadding(Ui.dp(this,14),Ui.dp(this,8),Ui.dp(this,14),Ui.dp(this,8));
            row.setBackground(Ui.bg(this,Ui.PANEL,9));
            row.setOnClickListener(v->{player.seekToDefaultPosition(pos);player.play();});
            queueHost.addView(row,Ui.lp(this,-1,44,0,0,0,6));
        }
    }
    private void refreshProgress(){
        if(player==null||seekBar==null)return;
        long length=player.getDuration();
        long now=player.getCurrentPosition();
        if(!scrubbing){
            seekBar.setMax((int)Math.min(Integer.MAX_VALUE,length>0?length:1));
            seekBar.setProgress((int)Math.min(Integer.MAX_VALUE,Math.max(0,now)));
            position.setText(Ui.time(now));
        }
        duration.setText(length>0?Ui.time(length):"LIVE / --:--");
    }
    private void showSpeed(){
        if(player==null)return;
        String[] values={"0.5×","0.75×","1.0×","1.25×","1.5×","1.75×","2.0×"};
        float[] speeds={.5f,.75f,1f,1.25f,1.5f,1.75f,2f};
        new AlertDialog.Builder(this).setTitle("Playback speed").setItems(values,(d,i)->player.setPlaybackSpeed(speeds[i])).show();
    }
    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(player!=null)player.removeListener(listener);
        if(future!=null)MediaController.releaseFuture(future);
        super.onDestroy();
    }
}
