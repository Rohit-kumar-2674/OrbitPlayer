package com.orbit.player;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.MimeTypes;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;

/** Native no-account media library. All preferences are stored on-device. */
public final class MainActivity extends Activity {
    private static final int REQUEST_LIBRARY = 61;
    private static final int REQUEST_FILE = 62;
    private final ArrayList<MediaEntry> videos = new ArrayList<>();
    private final ArrayList<MediaEntry> music = new ArrayList<>();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private OrbitStore store;
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private LinearLayout listHost;
    private LinearLayout miniBar;
    private TextView miniTitle;
    private TextView miniState;
    private String tab = "Videos";
    private String openPlaylist = "";
    private String searchTerm = "";
    private boolean scanning;
    private MediaEntry pendingOpen;

    private final Player.Listener listener = new Player.Listener() {
        @Override public void onEvents(Player player, Player.Events events) {
            renderMini();
        }
        @Override public void onPlayerError(androidx.media3.common.PlaybackException error) {
            Toast.makeText(MainActivity.this,"Playback failed: " + error.getErrorCodeName(),Toast.LENGTH_LONG).show();
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new OrbitStore(this);
        render();
        connectPlayer();
        if(!requestLibraryPermission())loadLibrary();
        handleOpenIntent(getIntent());
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleOpenIntent(intent);
    }
    private void connectPlayer() {
        SessionToken token = new SessionToken(this, new ComponentName(this, PlaybackService.class));
        controllerFuture = new MediaController.Builder(this, token).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                if (isFinishing() || isDestroyed()) return;
                controller = controllerFuture.get();
                controller.addListener(listener);
                renderMini();
                if(pendingOpen!=null){MediaEntry open=pendingOpen;pendingOpen=null;playEntries(Arrays.asList(open),open);}
            } catch (Exception e) {
                Toast.makeText(this,"Could not connect to player",Toast.LENGTH_LONG).show();
            }
        }, command -> handler.post(command));
    }
    private void handleOpenIntent(Intent i) {
        if (i == null || !Intent.ACTION_VIEW.equals(i.getAction()) || i.getData() == null) return;
        Uri uri = i.getData();
        String scheme = uri.getScheme();
        if (scheme == null) return;
        String mediaUri = uri.toString();
        String kind = (i.getType() != null && i.getType().startsWith("audio/")) ? "audio" : "video";
        if ("http".equals(scheme) || "https".equals(scheme) || "rtsp".equals(scheme)) kind="stream";
        MediaEntry entry = new MediaEntry(mediaUri, uri.getLastPathSegment(), "Opened from another app", kind, 0);
        if ((i.getFlags() & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0) {
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException ignored) {}
        }
        if(controller!=null)playEntries(Arrays.asList(entry),entry);
        else pendingOpen=entry;
    }
    private boolean requestLibraryPermission() {
        ArrayList<String> asks = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED)
                asks.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                asks.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            asks.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (!asks.isEmpty()) {
            requestPermissions(asks.toArray(new String[0]),REQUEST_LIBRARY);
            return true;
        }
        return false;
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == REQUEST_LIBRARY) loadLibrary();
    }
    private void loadLibrary() {
        if (scanning) return;
        scanning = true;
        worker.execute(() -> {
            ArrayList<MediaEntry> v = LibraryScanner.scan(this,"video");
            ArrayList<MediaEntry> a = LibraryScanner.scan(this,"audio");
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                videos.clear(); videos.addAll(v);
                music.clear(); music.addAll(a);
                scanning = false;
                renderList();
            });
        });
    }
    private void render() {
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(Ui.dp(this,18),Ui.dp(this,15),Ui.dp(this,18),Ui.dp(this,10));
        setContentView(root);

        LinearLayout brand=Ui.horizontal(this);
        LinearLayout branding=Ui.vertical(this);
        TextView heading=Ui.text(this,"ORBIT  /  PLAYER",21,Ui.WHITE,true);
        heading.setLetterSpacing(.06f);
        branding.addView(heading);
        TextView caption=Ui.text(this,"Your media. Your device. Your rules.",11,Ui.MUTED,false);
        branding.addView(caption,Ui.lp(this,-1,24,0,0,0,0));
        brand.addView(branding,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));
        TextView pick=Ui.button(this,"＋ FILE",false);
        pick.setOnClickListener(v -> openFilePicker());
        brand.addView(pick);
        root.addView(brand,Ui.lp(this,-1,58,0,0,0,8));

        HorizontalScrollView nav=new HorizontalScrollView(this);
        nav.setHorizontalScrollBarEnabled(false);
        LinearLayout navRow=Ui.horizontal(this);
        for (String option : new String[]{"Videos","Music","Streams","Favorites","Playlists"}) {
            TextView chip=Ui.button(this,option,option.equals(tab));
            chip.setOnClickListener(v -> {tab=option;openPlaylist="";searchTerm="";render();renderMini();});
            navRow.addView(chip,Ui.lp(this,-2,-2,0,0,8,0));
        }
        nav.addView(navRow);
        root.addView(nav,Ui.lp(this,-1,52,0,0,0,8));

        LinearLayout searchBox=Ui.horizontal(this);
        searchBox.setPadding(Ui.dp(this,12),0,Ui.dp(this,6),0);
        searchBox.setBackground(Ui.bg(this,Ui.PANEL,12));
        TextView searchIcon=Ui.text(this,"⌕",24,Ui.MUTED,false);
        searchBox.addView(searchIcon,Ui.lp(this,26,47,0,0,4,0));
        EditText search=new EditText(this);
        search.setSingleLine(true);
        search.setText(searchTerm);
        search.setHint("Search your media library");
        search.setTextColor(Ui.WHITE);
        search.setHintTextColor(Ui.MUTED);
        search.setTextSize(14);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                searchTerm=s.toString(); renderList();
            }
            @Override public void afterTextChanged(Editable e) {}
        });
        searchBox.addView(search,new LinearLayout.LayoutParams(0,Ui.dp(this,47),1));
        TextView refresh=Ui.button(this,"⟳",false);
        refresh.setOnClickListener(v -> loadLibrary());
        searchBox.addView(refresh,Ui.lp(this,43,39,4,0,0,0));
        root.addView(searchBox,Ui.lp(this,-1,49,0,0,0,10));

        LinearLayout toolbar=Ui.horizontal(this);
        TextView title=Ui.text(this,tab.toUpperCase(Locale.ROOT),12,Ui.BLUE,true);
        title.setLetterSpacing(.14f);
        toolbar.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,42),1));
        TextView action=Ui.button(this,tab.equals("Streams")?"＋ ADD STREAM":tab.equals("Playlists")?"＋ NEW LIST":"＋ OPEN",false);
        action.setOnClickListener(v -> {
            if (tab.equals("Streams")) streamDialog();
            else if (tab.equals("Playlists")) createPlaylistDialog();
            else openFilePicker();
        });
        toolbar.addView(action);
        root.addView(toolbar,Ui.lp(this,-1,46,0,0,0,3));

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        listHost=Ui.vertical(this);
        scroll.addView(listHost);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        miniBar=Ui.horizontal(this);
        miniBar.setBackground(Ui.bg(this,Ui.PANEL,14));
        miniBar.setPadding(Ui.dp(this,11),Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8));
        miniBar.setVisibility(View.GONE);
        TextView disc=Ui.text(this,"♫",25,Ui.BLUE,true);
        disc.setGravity(Gravity.CENTER);
        disc.setBackground(Ui.bg(this,Ui.PANEL2,10));
        miniBar.addView(disc,Ui.lp(this,46,48,0,0,10,0));
        LinearLayout miniInfo=Ui.vertical(this);
        miniTitle=Ui.text(this,"Nothing playing",14,Ui.WHITE,true);
        miniTitle.setSingleLine(true); miniTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        miniState=Ui.text(this,"Tap to open player",11,Ui.MUTED,false);
        miniInfo.addView(miniTitle,Ui.lp(this,-1,25,0,0,0,0));
        miniInfo.addView(miniState);
        miniInfo.setOnClickListener(v -> openCurrentPlayer());
        miniBar.addView(miniInfo,new LinearLayout.LayoutParams(0,Ui.dp(this,49),1));
        TextView prev=Ui.button(this,"|◀",false);
        prev.setOnClickListener(v -> {if (controller!=null && controller.hasPreviousMediaItem())controller.seekToPreviousMediaItem();});
        miniBar.addView(prev,Ui.lp(this,44,44,3,0,3,0));
        TextView toggle=Ui.button(this,"▶",true);
        toggle.setOnClickListener(v -> {if(controller!=null){if(controller.isPlaying())controller.pause();else controller.play();}});
        miniBar.addView(toggle,Ui.lp(this,45,44,0,0,0,0));
        miniBar.setTag(toggle);
        root.addView(miniBar,Ui.lp(this,-1,65,0,7,0,0));
        renderList();
        renderMini();
    }
    private List<MediaEntry> itemsForTab() {
        ArrayList<MediaEntry> entries=new ArrayList<>();
        switch (tab) {
            case "Videos":entries.addAll(videos);break;
            case "Music":entries.addAll(music);break;
            case "Streams":entries.addAll(store.streams());break;
            case "Favorites":
                Set<String> likes=store.favorites();
                for(MediaEntry e : allEntries()) if(likes.contains(e.uri))entries.add(e);
                break;
            case "Playlists":
                if (!openPlaylist.isEmpty()) {
                    List<MediaEntry> list=store.playlists().get(openPlaylist);
                    if(list!=null) entries.addAll(list);
                }
        }
        String filter=searchTerm.trim().toLowerCase(Locale.ROOT);
        if(!filter.isEmpty()) {
            for(java.util.Iterator<MediaEntry> it=entries.iterator();it.hasNext();) {
                MediaEntry entry=it.next();
                if(!entry.title.toLowerCase(Locale.ROOT).contains(filter) &&
                        !entry.artist.toLowerCase(Locale.ROOT).contains(filter))it.remove();
            }
        }
        return entries;
    }
    private List<MediaEntry> allEntries() {
        LinkedHashMap<String,MediaEntry> map=new LinkedHashMap<>();
        for(MediaEntry e:videos)map.put(e.uri,e);
        for(MediaEntry e:music)map.put(e.uri,e);
        for(MediaEntry e:store.streams())map.put(e.uri,e);
        for(List<MediaEntry> p:store.playlists().values()) for(MediaEntry e:p)map.put(e.uri,e);
        return new ArrayList<>(map.values());
    }
    private void renderList() {
        if(listHost==null)return;
        listHost.removeAllViews();
        if(tab.equals("Playlists") && openPlaylist.isEmpty()) {
            LinkedHashMap<String,ArrayList<MediaEntry>> lists=store.playlists();
            for(Map.Entry<String,ArrayList<MediaEntry>> e:lists.entrySet()) {
                LinearLayout line=rowBase();
                TextView symbol=cover("▤");line.addView(symbol,Ui.lp(this,53,53,0,0,12,0));
                LinearLayout desc=Ui.vertical(this);
                desc.addView(Ui.text(this,e.getKey(),16,Ui.WHITE,true));
                desc.addView(Ui.text(this,e.getValue().size()+" tracks",12,Ui.MUTED,false));
                line.addView(desc,new LinearLayout.LayoutParams(0,-2,1));
                TextView more=Ui.button(this,"⋮",false);
                more.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(e.getKey())
                        .setItems(new String[]{"Open playlist","Play all","Delete playlist"},(d,index)-> {
                            if(index==0) {openPlaylist=e.getKey();renderList();}
                            else if(index==1 && !e.getValue().isEmpty())playEntries(e.getValue(),e.getValue().get(0));
                            else if(index==2)new AlertDialog.Builder(this).setMessage("Delete this playlist? Tracks will remain on your device.")
                                    .setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->{store.deletePlaylist(e.getKey());renderList();}).show();
                        }).show());
                line.addView(more);
                line.setOnClickListener(v -> {openPlaylist=e.getKey();renderList();});
                listHost.addView(line,Ui.lp(this,-1,74,0,0,0,9));
            }
            if(lists.isEmpty()) emptyState("No playlists yet","Create a playlist to organize your favorites.");
            return;
        }
        if(tab.equals("Playlists") && !openPlaylist.isEmpty()) {
            TextView back=Ui.button(this,"← ALL PLAYLISTS  /  "+openPlaylist,false);
            back.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);
            back.setOnClickListener(v ->{openPlaylist="";renderList();});
            listHost.addView(back,Ui.lp(this,-1,47,0,0,0,12));
        }
        List<MediaEntry> entries=itemsForTab();
        TextView counter=Ui.text(this,entries.size()+" items  •  " + (scanning?"Scanning device…":"Ready"),11,Ui.MUTED,false);
        listHost.addView(counter,Ui.lp(this,-1,30,2,0,0,8));
        for(MediaEntry e:entries) {
            LinearLayout line=rowBase();
            TextView cover=cover(e.isVideo()?"▶":"♫");
            line.addView(cover,Ui.lp(this,53,53,0,0,12,0));
            LinearLayout details=Ui.vertical(this);
            TextView name=Ui.text(this,e.title,14,Ui.WHITE,true);
            name.setMaxLines(2);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            details.addView(name);
            String meta = e.artist.isEmpty()? ("stream".equals(e.kind)?"NETWORK STREAM":e.kind.toUpperCase(Locale.ROOT)):e.artist;
            if(e.duration>0)meta += "  •  "+Ui.time(e.duration);
            details.addView(Ui.text(this,meta,11,Ui.MUTED,false),Ui.lp(this,-1,22,0,2,0,0));
            line.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            TextView menu=Ui.button(this,"⋮",false);
            menu.setContentDescription("Options for " + e.title);
            menu.setOnClickListener(v -> itemMenu(e));
            line.addView(menu,Ui.lp(this,39,43,8,0,0,0));
            line.setOnClickListener(v ->playEntries(entries,e));
            line.setOnLongClickListener(v->{itemMenu(e);return true;});
            listHost.addView(line,Ui.lp(this,-1,73,0,0,0,8));
        }
        if(entries.isEmpty()) {
            String hint= tab.equals("Streams")?"Add an HLS, DASH, RTSP or direct media URL."
                    : tab.equals("Favorites")?"Heart tracks and videos to find them here."
                    : tab.equals("Playlists")?"Add tracks from the three-dot item menu."
                    : "Grant library permissions, or choose ＋ OPEN to select a file.";
            emptyState(searchTerm.isEmpty()?"No media found":"No search results", hint);
        }
    }
    private LinearLayout rowBase() {
        LinearLayout line=Ui.horizontal(this);
        line.setPadding(Ui.dp(this,9),Ui.dp(this,9),Ui.dp(this,9),Ui.dp(this,9));
        line.setBackground(Ui.bg(this,Ui.PANEL,13));
        line.setGravity(Gravity.CENTER_VERTICAL);
        return line;
    }
    private TextView cover(String symbol) {
        TextView v=Ui.text(this,symbol,22,Ui.BLUE,true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(Ui.bg(this,Ui.PANEL2,10));
        return v;
    }
    private void emptyState(String title,String desc) {
        LinearLayout container=Ui.vertical(this);
        container.setGravity(Gravity.CENTER);
        container.setPadding(Ui.dp(this,18),Ui.dp(this,52),Ui.dp(this,18),Ui.dp(this,52));
        TextView logo=Ui.text(this,"◈",54,Ui.BLUE,false);logo.setGravity(Gravity.CENTER);
        container.addView(logo);
        TextView t=Ui.text(this,title,18,Ui.WHITE,true);t.setGravity(Gravity.CENTER);
        container.addView(t);
        TextView d=Ui.text(this,desc,13,Ui.MUTED,false);
        d.setGravity(Gravity.CENTER);
        container.addView(d,Ui.lp(this,-1,60,0,8,0,0));
        if(tab.equals("Videos") || tab.equals("Music")) {
            TextView open=Ui.button(this,"OPEN MEDIA FILE",true);
            open.setOnClickListener(v ->openFilePicker());
            container.addView(open,Ui.lp(this,-2,44,0,2,0,0));
        }
        listHost.addView(container);
    }
    private void renderMini() {
        if(miniBar==null)return;
        if(controller==null || controller.getMediaItemCount()==0) {miniBar.setVisibility(View.GONE);return;}
        miniBar.setVisibility(View.VISIBLE);
        MediaItem item=controller.getCurrentMediaItem();
        if(item!=null)miniTitle.setText(item.mediaMetadata.title != null ? item.mediaMetadata.title : "Now playing");
        miniState.setText(controller.isPlaying()?"PLAYING • tap for full controls":"PAUSED • tap for full controls");
        TextView btn=(TextView)miniBar.getTag();
        btn.setText(controller.isPlaying()?"Ⅱ":"▶");
    }
    private void playEntries(List<MediaEntry> entries,MediaEntry chosen) {
        if(controller == null) {Toast.makeText(this,"Player is starting. Try again.",Toast.LENGTH_SHORT).show();return;}
        if(entries.isEmpty())return;
        ArrayList<MediaItem> items=new ArrayList<>();
        int index=0;
        for(int i=0;i<entries.size();i++) {
            items.add(entries.get(i).toItem());
            if(entries.get(i).uri.equals(chosen.uri)) index=i;
        }
        controller.setMediaItems(items,index,0);
        controller.prepare();
        controller.play();
        if(chosen.isVideo())startActivity(new Intent(this,VideoActivity.class));
        else startActivity(new Intent(this,MusicActivity.class));
        renderMini();
    }
    private void openCurrentPlayer() {
        if(controller==null || controller.getCurrentMediaItem()==null)return;
        String id=controller.getCurrentMediaItem().mediaId;
        boolean video=true;
        for(MediaEntry e:allEntries()) if(e.uri.equals(id)) {video=e.isVideo();break;}
        startActivity(new Intent(this,video?VideoActivity.class:MusicActivity.class));
    }
    private void itemMenu(MediaEntry e) {
        boolean favorite=store.favorites().contains(e.uri);
        ArrayList<String> choices=new ArrayList<>(Arrays.asList(favorite?"Remove from favorites":"Add to favorites","Add to playlist","Play next","Share link / media"));
        if("stream".equals(e.kind))choices.add("Remove saved stream");
        new AlertDialog.Builder(this).setTitle(e.title).setItems(choices.toArray(new String[0]),(dialog,which)-> {
            switch(which) {
                case 0: store.toggleFavorite(e.uri);renderList();break;
                case 1: choosePlaylist(e);break;
                case 2:
                    if(controller==null)break;
                    int next=controller.getCurrentMediaItemIndex()+1;
                    controller.addMediaItem(Math.min(next,controller.getMediaItemCount()),e.toItem());
                    Toast.makeText(this,"Added to queue",Toast.LENGTH_SHORT).show();break;
                case 3:
                    Uri shared=Uri.parse(e.uri);
                    Intent send=new Intent(Intent.ACTION_SEND);
                    if("content".equals(shared.getScheme())) {
                        send.setType(e.isVideo()?"video/*":"audio/*");
                        send.putExtra(Intent.EXTRA_STREAM,shared);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else {
                        send.setType("text/plain");
                        send.putExtra(Intent.EXTRA_TEXT,e.title + "\n" + e.uri);
                    }
                    startActivity(Intent.createChooser(send,"Share media"));break;
                case 4:store.deleteStream(e.uri);renderList();break;
            }
        }).show();
    }
    private void choosePlaylist(MediaEntry e) {
        ArrayList<String> names=new ArrayList<>(store.playlists().keySet());
        names.add("＋ Create new playlist");
        new AlertDialog.Builder(this).setTitle("Add to playlist").setItems(names.toArray(new String[0]),(d,index)-> {
            if(index==names.size()-1)createPlaylistDialog(e);
            else {store.addToPlaylist(names.get(index),e);Toast.makeText(this,"Added to " + names.get(index),Toast.LENGTH_SHORT).show();}
        }).show();
    }
    private EditText field(String hint,String text) {
        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Ui.WHITE);
        input.setHintTextColor(Ui.MUTED);
        input.setHint(hint);
        input.setText(text);
        return input;
    }
    private void createPlaylistDialog() {createPlaylistDialog(null);}
    private void createPlaylistDialog(MediaEntry selected) {
        EditText name=field("Playlist name","");
        LinearLayout layout=Ui.vertical(this);layout.setPadding(Ui.dp(this,20),0,Ui.dp(this,20),0);
        layout.addView(name);
        new AlertDialog.Builder(this).setTitle("Create playlist").setView(layout)
                .setNegativeButton("Cancel",null).setPositiveButton("Create",(d,index)-> {
                    String value=name.getText().toString().trim();
                    if(value.isEmpty())return;
                    store.createPlaylist(value);
                    if(selected!=null)store.addToPlaylist(value,selected);
                    renderList();
                }).show();
    }
    private void streamDialog() {
        LinearLayout layout=Ui.vertical(this);
        layout.setPadding(Ui.dp(this,20),Ui.dp(this,8),Ui.dp(this,20),0);
        EditText name=field("Stream name (optional)","");
        EditText link=field("https://… or rtsp://…","");
        Spinner type=new Spinner(this);
        String[] types={"Auto detect","HLS / M3U8","MPEG-DASH / MPD","Direct media / RTSP"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types);
        type.setAdapter(adapter);
        layout.addView(name,Ui.lp(this,-1,52,0,0,0,10));
        layout.addView(link,Ui.lp(this,-1,52,0,0,0,10));
        layout.addView(type);
        AlertDialog alert=new AlertDialog.Builder(this).setTitle("Open network stream")
                .setView(layout).setNegativeButton("Cancel",null).setPositiveButton("Save and play",null).create();
        alert.setOnShowListener(d -> alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String raw=link.getText().toString().trim();
            Uri uri=Uri.parse(raw);
            String scheme=uri.getScheme();
            if(scheme==null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("rtsp"))
                    || uri.getHost()==null || uri.getHost().isEmpty()) {
                link.setError("Enter a valid HTTP(S) or RTSP media URL");return;
            }
            String mime="";
            if(type.getSelectedItemPosition()==1)mime= MimeTypes.APPLICATION_M3U8;
            if(type.getSelectedItemPosition()==2)mime= MimeTypes.APPLICATION_MPD;
            String title=name.getText().toString().trim();
            if(title.isEmpty())title=uri.getHost();
            MediaEntry entry=new MediaEntry(raw,title,"Network stream","stream",0,mime);
            store.saveStream(entry);
            alert.dismiss();renderList();
            playEntries(Arrays.asList(entry),entry);
        }));
        alert.show();
    }
    private void openFilePicker() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"audio/*","video/*","application/x-mpegURL","application/vnd.apple.mpegurl","application/dash+xml","application/octet-stream"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,REQUEST_FILE);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=REQUEST_FILE || result!=RESULT_OK || data==null || data.getData()==null)return;
        Uri uri=data.getData();
        try {getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}
        catch(SecurityException ignored) {}
        String mime=getContentResolver().getType(uri);
        String kind=mime!=null && mime.startsWith("audio/")?"audio":"video";
        String title=uri.getLastPathSegment();
        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(c!=null && c.moveToFirst()) title=c.getString(0);
        }catch(Exception ignored) {}
        MediaEntry e=new MediaEntry(uri.toString(),title,"Picked file",kind,0);
        playEntries(Arrays.asList(e),e);
    }
    @Override protected void onResume() {super.onResume();renderMini();}
    @Override protected void onDestroy() {
        worker.shutdownNow();
        if(controller!=null)controller.removeListener(listener);
        if(controllerFuture!=null)MediaController.releaseFuture(controllerFuture);
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
