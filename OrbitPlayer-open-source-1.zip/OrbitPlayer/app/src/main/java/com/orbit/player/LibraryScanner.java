package com.orbit.player;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;

/** Reads audio/video metadata via scoped MediaStore with read-only permissions. */
public final class LibraryScanner {
    private LibraryScanner() {}
    public static ArrayList<MediaEntry> scan(Context context, String kind) {
        ArrayList<MediaEntry> found = new ArrayList<>();
        boolean audio = "audio".equals(kind);
        Uri base = audio ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] columns = audio
                ? new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ARTIST}
                : new String[]{MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.TITLE, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.RESOLUTION};
        try (Cursor cursor = context.getContentResolver().query(base, columns, null, null,
                MediaStore.MediaColumns.DATE_ADDED + " DESC")) {
            if (cursor != null) while (cursor.moveToNext()) {
                String name = cursor.getString(2);
                if (name == null || name.trim().isEmpty()) name = cursor.getString(1);
                String subtitle = cursor.getString(4);
                long duration = cursor.isNull(3) ? 0 : cursor.getLong(3);
                Uri contentUri = ContentUris.withAppendedId(base, cursor.getLong(0));
                found.add(new MediaEntry(contentUri.toString(), name, subtitle, kind, duration));
            }
        } catch (SecurityException | IllegalArgumentException ignored) {
            // Permissions may have changed while the user was browsing the library.
        }
        java.util.Collections.sort(found, (a,b) -> a.title.toLowerCase(Locale.ROOT).compareTo(b.title.toLowerCase(Locale.ROOT)));
        return found;
    }
}
