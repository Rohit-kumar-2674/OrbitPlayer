package com.orbit.player;

import android.net.Uri;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Locale;

/** Lightweight serializable MediaStore or user-supplied stream entry. */
public final class MediaEntry {
    public final String uri;
    public final String title;
    public final String artist;
    public final String kind;
    public final long duration;
    public final String mime;

    public MediaEntry(String uri, String title, String artist, String kind, long duration) {
        this(uri, title, artist, kind, duration, "");
    }
    public MediaEntry(String uri, String title, String artist, String kind, long duration, String mime) {
        this.uri = uri;
        this.title = title == null || title.trim().isEmpty() ? "Untitled" : title;
        this.artist = artist == null ? "" : artist;
        this.kind = kind == null ? "video" : kind;
        this.duration = duration;
        this.mime = mime == null ? "" : mime;
    }

    public MediaItem toItem() {
        MediaMetadata metadata = new MediaMetadata.Builder().setTitle(title).setArtist(artist).build();
        MediaItem.Builder builder = new MediaItem.Builder().setUri(Uri.parse(uri))
                .setMediaId(uri).setMediaMetadata(metadata);
        if (!mime.isEmpty()) builder.setMimeType(mime);
        else if (uri.toLowerCase(Locale.ROOT).contains(".m3u8")) builder.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (uri.toLowerCase(Locale.ROOT).contains(".mpd")) builder.setMimeType(MimeTypes.APPLICATION_MPD);
        return builder.build();
    }
    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("uri", uri); o.put("title", title); o.put("artist", artist);
        o.put("kind", kind); o.put("duration", duration); o.put("mime", mime);
        return o;
    }
    public static MediaEntry fromJson(JSONObject o) {
        return new MediaEntry(o.optString("uri"),o.optString("title"),o.optString("artist"),
                o.optString("kind","video"),o.optLong("duration"),o.optString("mime"));
    }
    public boolean isVideo() {
        if ("video".equals(kind) || "stream".equals(kind)) return true;
        if ("audio".equals(kind)) return false;
        String p = uri.toLowerCase(Locale.ROOT);
        return p.contains(".mp4") || p.contains(".mkv") || p.contains(".webm") || p.startsWith("rtsp:");
    }
}
