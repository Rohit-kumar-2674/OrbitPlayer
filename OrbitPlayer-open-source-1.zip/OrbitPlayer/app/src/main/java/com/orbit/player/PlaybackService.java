package com.orbit.player;

import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

/** Media3 managed session provides system media controls, notification & audio focus. */
public final class PlaybackService extends MediaSessionService {
    private ExoPlayer player;
    private MediaSession session;

    @Override public void onCreate() {
        super.onCreate();
        player=new ExoPlayer.Builder(this).build();
        player.setAudioAttributes(AudioAttributes.DEFAULT,true);
        player.setHandleAudioBecomingNoisy(true);
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        session=new MediaSession.Builder(this,player).build();
    }
    @Override @Nullable public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return session;
    }
    @Override public void onDestroy() {
        if(session!=null) {session.release();session=null;}
        if(player!=null) {player.release();player=null;}
        super.onDestroy();
    }
}
