package com.orbit.player;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Local-only data: favorites, saved streams and user playlists. */
public final class OrbitStore {
    private final SharedPreferences prefs;
    public OrbitStore(Context ctx) { prefs = ctx.getSharedPreferences("orbit_store_v1",Context.MODE_PRIVATE); }

    public ArrayList<MediaEntry> streams() { return readEntries(prefs.getString("streams","[]")); }
    public void saveStream(MediaEntry entry) {
        ArrayList<MediaEntry> streams=streams();
        for (java.util.Iterator<MediaEntry> it=streams.iterator();it.hasNext();) {
            if(it.next().uri.equals(entry.uri))it.remove();
        }
        streams.add(0,entry);
        prefs.edit().putString("streams",entriesJson(streams)).apply();
    }
    public void deleteStream(String uri) {
        ArrayList<MediaEntry> streams=streams(); for(java.util.Iterator<MediaEntry> it=streams.iterator();it.hasNext();) {
            if(it.next().uri.equals(uri))it.remove();
        }
        prefs.edit().putString("streams",entriesJson(streams)).apply();
    }

    public Set<String> favorites() {
        HashSet<String> result = new HashSet<>();
        JSONArray arr = jsonArray(prefs.getString("favorites","[]"));
        for(int i=0;i<arr.length();i++) result.add(arr.optString(i));
        return result;
    }
    public boolean toggleFavorite(String uri) {
        Set<String> set=favorites();
        boolean result;
        if(set.contains(uri)) {set.remove(uri); result=false;}
        else {set.add(uri); result=true;}
        prefs.edit().putString("favorites",new JSONArray(set).toString()).apply();
        return result;
    }

    public LinkedHashMap<String,ArrayList<MediaEntry>> playlists() {
        LinkedHashMap<String,ArrayList<MediaEntry>> data=new LinkedHashMap<>();
        JSONObject obj;
        try {obj = new JSONObject(prefs.getString("playlists","{}"));}
        catch (JSONException exc) {return data;}
        java.util.Iterator<String> keys=obj.keys();
        while(keys.hasNext()) {
            String key=keys.next();
            data.put(key,readEntries(obj.optJSONArray(key)));
        }
        return data;
    }
    public void createPlaylist(String name) {
        Map<String,ArrayList<MediaEntry>> m=playlists();
        if(!m.containsKey(name)) {m.put(name,new ArrayList<>()); savePlaylists(m);}
    }
    public void addToPlaylist(String name,MediaEntry entry) {
        Map<String,ArrayList<MediaEntry>> m=playlists();
        ArrayList<MediaEntry> items=m.get(name);
        if(items==null) {items=new ArrayList<>();m.put(name,items);}
        boolean exists=false;
        for(MediaEntry e:items) if(e.uri.equals(entry.uri)) {exists=true;break;}
        if(!exists) items.add(entry);
        savePlaylists(m);
    }
    public void deletePlaylist(String name) {
        Map<String,ArrayList<MediaEntry>> m=playlists();m.remove(name);savePlaylists(m);
    }
    private void savePlaylists(Map<String,ArrayList<MediaEntry>> m) {
        JSONObject obj = new JSONObject();
        for(Map.Entry<String,ArrayList<MediaEntry>> entry:m.entrySet()) {
            try { obj.put(entry.getKey(),jsonArray(entry.getValue())); }
            catch(JSONException ignored) {}
        }
        prefs.edit().putString("playlists",obj.toString()).apply();
    }
    private static String entriesJson(List<MediaEntry> entries) {return jsonArray(entries).toString();}
    private static JSONArray jsonArray(List<MediaEntry> entries) {
        JSONArray a=new JSONArray();
        for(MediaEntry e: entries) {try{a.put(e.toJson());}catch(JSONException ignored){}}
        return a;
    }
    private static JSONArray jsonArray(String s) {
        try{return new JSONArray(s);}catch(JSONException e){return new JSONArray();}
    }
    private static ArrayList<MediaEntry> readEntries(String s) {return readEntries(jsonArray(s));}
    private static ArrayList<MediaEntry> readEntries(JSONArray arr) {
        ArrayList<MediaEntry> result=new ArrayList<>();if(arr==null)return result;
        for(int i=0;i<arr.length();i++) {
            JSONObject obj=arr.optJSONObject(i);
            if(obj!=null && !obj.optString("uri").isEmpty())result.add(MediaEntry.fromJson(obj));
        }
        return result;
    }
}
