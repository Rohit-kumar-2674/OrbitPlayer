package com.orbit.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Collections;
import java.util.Locale;

/** Video player with captions, aspect ratio, speed, landscape and PiP controls. */
public final class VideoActivity extends Activity {
    private static final int REQUEST_CAPTIONS=301;
    private MediaController player;
    private ListenableFuture<MediaController> future;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private PlayerView surface;
    private LinearLayout controls;
    private TextView title;
    private int aspectIndex=0;
    private final Player.Listener listener=new Player.Listener(){
        @Override public void onEvents(Player p,Player.Events events){
            MediaItem item=p.getCurrentMediaItem();
            if(title!=null)title.setText(item!=null && item.mediaMetadata.title!=null?item.mediaMetadata.title:"Orbit Player");
            if(surface!=null)surface.setKeepScreenOn(p.isPlaying());
        }
        @Override public void onPlayerError(androidx.media3.common.PlaybackException e){
            new AlertDialog.Builder(VideoActivity.this).setTitle("Playback error")
                    .setMessage("Playback failed: "+e.getErrorCodeName()+"\n\nThis file or stream may require a codec or protocol not supported by your device.")
                    .setPositiveButton("OK",null).show();
        }
    };
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        render();
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class));
        future=new MediaController.Builder(this,token).buildAsync();
        future.addListener(()->{
            try{
                if(isFinishing()||isDestroyed())return;
                player=future.get();player.addListener(listener);
                surface.setPlayer(player);
                MediaItem item=player.getCurrentMediaItem();
                if(item!=null&&item.mediaMetadata.title!=null)title.setText(item.mediaMetadata.title);
            }catch(Exception e){Toast.makeText(this,"Player could not start",Toast.LENGTH_LONG).show();}
        },command->handler.post(command));
    }
    private void render(){
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        LinearLayout root=Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);
        LinearLayout header=Ui.horizontal(this);
        header.setPadding(Ui.dp(this,15),Ui.dp(this,8),Ui.dp(this,15),Ui.dp(this,8));
        TextView back=Ui.button(this,"←",false);back.setOnClickListener(v->finish());
        header.addView(back);
        title=Ui.text(this,"ORBIT PLAYER",15,Ui.WHITE,true);
        title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        header.addView(title,new LinearLayout.LayoutParams(0,Ui.dp(this,50),1));
        TextView pip=Ui.button(this,"PIP",false);
        pip.setOnClickListener(v->enterPip());
        header.addView(pip);
        root.addView(header,Ui.lp(this,-1,66,0,0,0,0));
        surface=new PlayerView(this);
        surface.setBackgroundColor(android.graphics.Color.BLACK);
        surface.setUseController(true);
        surface.setControllerShowTimeoutMs(4000);
        surface.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        surface.setShowSubtitleButton(true);
        root.addView(surface,new LinearLayout.LayoutParams(-1,0,1));
        controls=Ui.vertical(this);
        controls.setPadding(Ui.dp(this,14),Ui.dp(this,13),Ui.dp(this,14),Ui.dp(this,20));
        LinearLayout topRow=Ui.horizontal(this);
        addButton(topRow,"−10s",()->seekDelta(-10000));
        addButton(topRow,"+10s",()->seekDelta(10000));
        addButton(topRow,"SPEED",this::chooseSpeed);
        addButton(topRow,"ASPECT",this::cycleAspect);
        controls.addView(topRow);
        LinearLayout bottomRow=Ui.horizontal(this);
        addButton(bottomRow,"SUBTITLES",this::openSubtitles);
        addButton(bottomRow,"ROTATE",this::rotateScreen);
        addButton(bottomRow,"AUDIO",this::showAudioHelp);
        controls.addView(bottomRow,Ui.lp(this,-1,53,0,7,0,0));
        root.addView(controls);
    }
    private void addButton(LinearLayout parent,String text,Runnable action){
        TextView b=Ui.button(this,text,false);
        parent.addView(b,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)b.getLayoutParams();
        p.setMargins(Ui.dp(this,3),0,Ui.dp(this,3),0);
        b.setLayoutParams(p);
        b.setOnClickListener(v->action.run());
    }
    private void seekDelta(long ms){
        if(player==null)return;
        long target=Math.max(0,player.getCurrentPosition()+ms);
        long length=player.getDuration();
        if(length>0)target=Math.min(length,target);
        player.seekTo(target);
    }
    private void chooseSpeed(){
        if(player==null)return;
        String[] names={"0.5×","0.75×","1.0×","1.25×","1.5×","1.75×","2.0×"};
        float[] speeds={.5f,.75f,1f,1.25f,1.5f,1.75f,2f};
        new AlertDialog.Builder(this).setTitle("Playback speed").setItems(names,(d,index)->player.setPlaybackSpeed(speeds[index])).show();
    }
    private void cycleAspect(){
        aspectIndex=(aspectIndex+1)%3;
        int[] values={AspectRatioFrameLayout.RESIZE_MODE_FIT,AspectRatioFrameLayout.RESIZE_MODE_FILL,
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM};
        surface.setResizeMode(values[aspectIndex]);
        Toast.makeText(this,new String[]{"Fit","Stretch","Zoom"}[aspectIndex],Toast.LENGTH_SHORT).show();
    }
    private void rotateScreen(){
        boolean landscape=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;
        setRequestedOrientation(landscape?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }
    private void openSubtitles(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,REQUEST_CAPTIONS);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=REQUEST_CAPTIONS||result!=RESULT_OK||data==null||data.getData()==null||player==null)return;
        Uri uri=data.getData();
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}
        catch(SecurityException ignored){}
        MediaItem item=player.getCurrentMediaItem();
        if(item==null)return;
        String name=uri.getLastPathSegment()==null?"":uri.getLastPathSegment().toLowerCase(Locale.ROOT);
        String mime=name.endsWith(".vtt")?MimeTypes.TEXT_VTT:
                name.endsWith(".ssa")||name.endsWith(".ass")?MimeTypes.TEXT_SSA:
                MimeTypes.APPLICATION_SUBRIP;
        MediaItem.SubtitleConfiguration sub=new MediaItem.SubtitleConfiguration.Builder(uri)
                .setMimeType(mime).setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build();
        MediaItem newItem=item.buildUpon().setSubtitleConfigurations(Collections.singletonList(sub)).build();
        int index=player.getCurrentMediaItemIndex();
        long time=player.getCurrentPosition();
        boolean playing=player.getPlayWhenReady();
        player.replaceMediaItem(index,newItem);
        player.seekTo(index,time);
        player.setPlayWhenReady(playing);
        Toast.makeText(this,"External subtitles loaded",Toast.LENGTH_SHORT).show();
    }
    private void showAudioHelp(){
        new AlertDialog.Builder(this).setTitle("Audio and subtitles")
                .setMessage("For embedded audio and subtitle tracks, tap the player screen and open the track/settings controls. You can also load an external SRT, VTT, ASS or SSA file using SUBTITLES.")
                .setPositiveButton("OK",null).show();
    }
    private void enterPip(){
        if(Build.VERSION.SDK_INT < 26 || player==null)return;
        try{
            PictureInPictureParams params=new PictureInPictureParams.Builder().setAspectRatio(new Rational(16,9)).build();
            enterPictureInPictureMode(params);
        }catch(IllegalStateException e){Toast.makeText(this,"Picture-in-picture not available",Toast.LENGTH_SHORT).show();}
    }
    @Override public void onUserLeaveHint(){
        super.onUserLeaveHint();
        if(Build.VERSION.SDK_INT>=26 && player!=null && player.isPlaying())enterPip();
    }
    @Override public void onPictureInPictureModeChanged(boolean inPip,Configuration config){
        super.onPictureInPictureModeChanged(inPip,config);
        if(controls!=null)controls.setVisibility(inPip?View.GONE:View.VISIBLE);
        surface.setUseController(!inPip);
    }
    @Override protected void onDestroy(){
        surface.setPlayer(null);
        if(player!=null)player.removeListener(listener);
        if(future!=null)MediaController.releaseFuture(future);
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
