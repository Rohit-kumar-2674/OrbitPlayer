package com.orbit.player;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.LinearLayout;

final class Ui {
    static final int BG=Color.rgb(9,14,23);
    static final int PANEL=Color.rgb(22,31,47);
    static final int PANEL2=Color.rgb(29,42,61);
    static final int BLUE=Color.rgb(103,199,255);
    static final int WHITE=Color.rgb(242,247,255);
    static final int MUTED=Color.rgb(145,160,179);
    static int dp(Context c,float value) {return (int)(value*c.getResources().getDisplayMetrics().density+0.5f);}
    static GradientDrawable bg(Context c,int color,int radius) {
        GradientDrawable g=new GradientDrawable();
        g.setColor(color);g.setCornerRadius(dp(c,radius));return g;
    }
    static TextView text(Context c,String value,int size,int color,boolean bold) {
        TextView t=new TextView(c); t.setText(value);t.setTextColor(color);t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    static TextView button(Context c,String value,boolean primary) {
        TextView t=text(c,value,13,primary?BG:WHITE,true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c,14),dp(c,11),dp(c,14),dp(c,11));
        t.setBackground(bg(c,primary?BLUE:PANEL2,12));
        t.setClickable(true);
        return t;
    }
    static LinearLayout vertical(Context c) {
        LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;
    }
    static LinearLayout horizontal(Context c) {
        LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);return l;
    }
    static LinearLayout.LayoutParams lp(Context c,int w,int h,int left,int top,int right,int bottom) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(c,w),h<0?h:dp(c,h));
        p.setMargins(dp(c,left),dp(c,top),dp(c,right),dp(c,bottom));return p;
    }
    static String time(long ms) {
        if(ms<=0 || ms==Long.MIN_VALUE || ms==Long.MAX_VALUE)return "--:--";
        long seconds=ms/1000; long hours=seconds/3600;long minutes=(seconds/60)%60;long secs=seconds%60;
        if(hours>0)return String.format(java.util.Locale.ROOT,"%d:%02d:%02d",hours,minutes,secs);
        return String.format(java.util.Locale.ROOT,"%d:%02d",minutes,secs);
    }
}
