# Contributing to Orbit Player

Thanks for helping make independent Android media playback better.

1. Open an issue describing the fix/feature and expected behavior.
2. Keep the project original. Do not copy proprietary UI resources, icons, code, paid APKs, or unauthorized codec binaries.
3. Use Java and AndroidX Media3 APIs, respect scoped storage and Android privacy guidelines.
4. Validate on a phone or emulator and describe Android version, test content type, steps and result.
5. Submit a pull request with a focused change and describe any required permissions or dependencies.

Be kind in discussions. Do not commit keys, certificates, private URLs, user media, or screenshots containing personal information.
