# Security policy

This is an early-stage Android project without a completed security audit.

- Do not upload secrets, API credentials or tokens to issues. Never commit signing keys.
- Stream URLs can contain sensitive credentials. Orbit Player currently stores saved URLs as app-private, unencrypted Android preferences; use only trusted media endpoints.
- When using HTTP rather than HTTPS, network traffic can be observed or modified by others on the same path.
- Use official Android system file pickers for user-selected media.
- Do not redistribute protected codecs or proprietary app code as part of this project.

For sensitive security disclosures, use GitHub's private vulnerability reporting feature after repository publication if enabled, rather than a public issue.
