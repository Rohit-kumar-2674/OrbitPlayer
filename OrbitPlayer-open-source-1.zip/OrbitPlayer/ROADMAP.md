# Roadmap

## 0.1.0 — implemented in source, pending build and device validation

- Android native library with videos/music, media metadata, search
- Playback using AndroidX Media3 with HTTP(S), HLS, DASH, RTSP modules
- Media session background music / notification
- Stream saving, local favorites, playlists and queue
- Video settings including aspect, speed, subtitles, rotation and PiP
- Fully automated GitHub Actions APK build workflow

## Next milestones (NOT IMPLEMENTED)

- First successful CI build and physical-device smoke tests across Android 6–16
- Mobile-optimized gesture seek, volume and brightness adjustments
- Resumable playback positions, sort/filter, folders and thumbnails
- Stable release signing, GitHub Releases, update path
- Equalizer, sleep timer and audio effects
- Network SMB/FTP/DLNA servers, IPTV playlist parser
- TV/Chromecast support and richer accessibility/test coverage
- Optional appropriately licensed codecs/decoders where legally permitted

Please don't advertise a roadmap item as working until its implementation and device tests are complete.
